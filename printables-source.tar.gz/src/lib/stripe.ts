import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_placeholder", {
  apiVersion: "2024-09-30.acacia" as any,
});

export const STRIPE_PRICE_ID = process.env.STRIPE_PRICE_ID || "";
